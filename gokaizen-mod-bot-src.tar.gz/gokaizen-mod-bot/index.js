require('dotenv').config();
const fs = require('fs');
const path = require('path');
const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    PermissionFlagsBits,
    PermissionsBitField,
    SlashCommandBuilder,
    ActivityType,
} = require('discord.js');

const TOKEN = process.env.TOKEN || process.env.DISCORD_TOKEN;
const RED = 0xFF0000;
const MAX_SCAN = 2000;

const IMAGE_THRESHOLD = 4;
const ALERT_ROLES = ['1376416212724088932', '1520325600185684028'];
const WHITELIST_ROLES = ['1376416212724088932', '1386874017105051759', '1367316783832502282']; 
const DB_PATH = path.join(__dirname, 'radar-channels.json');
const RESPONDER_DB_PATH = path.join(__dirname, 'responders.json');

// Balasan statis untuk command "gosmed" (bisa dipakai semua member)
const GOSMED_REPLY =
    '**PUNYA GOKAIZEN**\n\n' +
    '`FOLLOW :`\n' +
    '- https://www.instagram.com/gokaizencommunity\n' +
    '- https://www.tiktok.com/@gokaizencommunity?\n\n' +
    '`SUPPORT :`\n\n' +
    '`DISCORD KITA :`\n' +
    '- https://discord.gg/gokaizen';

if (!TOKEN) {
    console.error('❌ TOKEN is not set. Create a .env file with:  TOKEN=your_bot_token');
    process.exit(1);
}

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
    ] 
});

const redEmbed = (description, title) => {
    const e = new EmbedBuilder().setColor(RED).setDescription(description);
    if (title) e.setTitle(title);
    return e;
};

function loadRadarChannels() {
    try {
        if (fs.existsSync(DB_PATH)) {
            return new Map(Object.entries(JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))));
        }
    } catch (err) {}
    return new Map();
}

function saveRadarChannels(map) {
    try {
        const tmp = `${DB_PATH}.tmp`;
        fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(map), null, 2));
        fs.renameSync(tmp, DB_PATH);
    } catch (err) {}
}

function loadResponders() {
    try {
        if (fs.existsSync(RESPONDER_DB_PATH)) {
            return new Map(Object.entries(JSON.parse(fs.readFileSync(RESPONDER_DB_PATH, 'utf8'))));
        }
    } catch (err) {}
    return new Map();
}

function saveResponders(map) {
    try {
        const tmp = `${RESPONDER_DB_PATH}.tmp`;
        fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(map), null, 2));
        fs.renameSync(tmp, RESPONDER_DB_PATH);
    } catch (err) {}
}

const radarChannels = loadRadarChannels();
const responders = loadResponders();

async function collectUserMessages(channel, userId, maxScan) {
    const collected = [];
    let lastId = null;
    let scanned = 0;
    while (scanned < maxScan) {
        const options = { limit: 100 };
        if (lastId) options.before = lastId;
        const batch = await channel.messages.fetch(options);
        if (batch.size === 0) break;
        for (const msg of batch.values()) {
            if (msg.author.id === userId) collected.push(msg);
        }
        scanned += batch.size;
        lastId = batch.last().id;
        if (batch.size < 100) break;
    }
    return collected; 
}

async function bulkDeleteMessages(channel, messages) {
    const TWO_WEEKS = 14 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const deletable = messages.filter(m => (now - m.createdTimestamp) < TWO_WEEKS);
    const tooOld = messages.length - deletable.length;
    let deleted = 0;
    for (let i = 0; i < deletable.length; i += 100) {
        const chunk = deletable.slice(i, i + 100);
        if (chunk.length === 1) {
            await chunk[0].delete().catch(() => null);
            deleted += 1;
        } else if (chunk.length > 1) {
            const res = await channel.bulkDelete(chunk, true);
            deleted += res.size;
        }
    }
    return { deleted, tooOld };
}

const helpCmd = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show the list of available commands'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(RED)
            .setAuthor({
                name: `${interaction.client.user.username} — Moderation`,
                iconURL: interaction.client.user.displayAvatarURL(),
            })
            .setTitle('Command Gokaizen Staff')
            .setDescription(
                '**`/ban`** - Ban a user by ID or mention.\n' +
                '**`/clearmsg`** - Delete all of a user\'s messages in the channel.\n' +
                '**`/deletemsg`** - Delete a set number of a user\'s recent messages.\n' +
                '**`/copyperm`** - Copy permissions from one channel to another.\n' +
                '**`/setupradar`** - Set this channel as the Scam Radar Alert log.\n' +
                '**`/addresponder`** - Tambah custom auto-responder untuk user tertentu.\n' +
                '**`/delresponder`** - Hapus custom auto-responder.\n' +
                '**`/listresponder`** - Lihat daftar auto-responder & pemiliknya.\n' +
                '**`.warp`** - Pindah ke voice channel user lain (menggunakan prefix).\n' +
                '**`/help`** - Show this command list.'
            )
            .setTimestamp();
        return interaction.reply({ embeds: [embed] }); 
    },
};

const setupRadarCmd = {
    data: new SlashCommandBuilder()
        .setName('setupradar')
        .setDescription('Setup channel ini sebagai Radar Gokaizen (log ancaman)')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        radarChannels.set(interaction.guildId, interaction.channelId);
        saveRadarChannels(radarChannels);
        return interaction.reply({ content: `✅ Setup berhasil. Sistem Radar Gokaizen akan mengirimkan log deteksi ancaman ke channel ${interaction.channel} ini.`, ephemeral: true });
    },
};

const banCmd = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a user by ID or mention')
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addStringOption(o => o.setName('user').setDescription('User ID or mention').setRequired(true))
        .addIntegerOption(o => o.setName('days').setDescription('Delete messages from last N days (0-7)').setMinValue(0).setMaxValue(7))
        .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setMaxLength(500)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers))
            return interaction.editReply({ embeds: [redEmbed('I\'m missing the **Ban Members** permission.', 'Missing Permission')] });

        const client = interaction.client;
        const targetId = interaction.options.getString('user').replace(/[<@!>]/g, '').trim();
        const deleteDays = interaction.options.getInteger('days') ?? 0;
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (!/^\d{17,20}$/.test(targetId)) return interaction.editReply({ embeds: [redEmbed('Please provide a valid Discord user ID.', 'Invalid ID')] });
        if (targetId === interaction.user.id || targetId === interaction.guild.ownerId || targetId === client.user.id) 
            return interaction.editReply({ embeds: [redEmbed('Action not allowed on this user.', 'Action Not Allowed')] });

        const targetMember = await interaction.guild.members.fetch(targetId).catch(() => null);
        if (targetMember) {
            const me = interaction.guild.members.me;
            if (me.roles.highest.position <= targetMember.roles.highest.position || 
               (targetMember.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== interaction.guild.ownerId))
                return interaction.editReply({ embeds: [redEmbed('Role hierarchy prevents this action.', 'Insufficient Role')] });
        }

        const existingBan = await interaction.guild.bans.fetch(targetId).catch(() => null);
        if (existingBan) return interaction.editReply({ embeds: [redEmbed('This user is already banned.', 'Already Banned')] });

        try {
            const targetUser = await client.users.fetch(targetId).catch(() => null);
            if (targetMember && targetUser) {
                await targetUser.send({ embeds: [new EmbedBuilder().setColor(RED).setTitle(`You have been banned from ${interaction.guild.name}`).addFields({ name: 'Reason', value: reason }).setTimestamp()] }).catch(() => null);
            }

            await interaction.guild.bans.create(targetId, { deleteMessageSeconds: deleteDays * 86400, reason: `${reason} — by ${interaction.user.tag}` });

            const embed = new EmbedBuilder().setColor(RED).setTitle('User Banned')
                .addFields(
                    { name: 'User', value: targetUser ? `${targetUser.tag} (\`${targetId}\`)` : `\`${targetId}\``, inline: false },
                    { name: 'Moderator', value: interaction.user.tag, inline: true },
                    { name: 'Messages Deleted', value: deleteDays > 0 ? `Last ${deleteDays} day(s)` : 'None', inline: true },
                    { name: 'Reason', value: reason, inline: false },
                ).setTimestamp();
            if (targetUser) embed.setThumbnail(targetUser.displayAvatarURL());

            return interaction.editReply({ embeds: [embed] });
        } catch (err) {
            return interaction.editReply({ embeds: [redEmbed(`Failed to ban: ${err.message}`, 'Error')] });
        }
    },
};
const clearmsgCmd = {
    data: new SlashCommandBuilder()
        .setName('clearmsg')
        .setDescription('Delete all of a user\'s messages across ALL channels (last 14 days)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addUserOption(o => o.setName('user').setDescription('The user whose messages will be deleted').setRequired(true)),
        
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageMessages))
            return interaction.editReply({ embeds: [redEmbed('I\'m missing the **Manage Messages** permission in this server.', 'Missing Permission')] });

        const target = interaction.options.getUser('user');
        
        // Ambil semua channel yang berbasis teks (text channel, thread, voice text, dll)
        const textChannels = interaction.guild.channels.cache.filter(c => c.isTextBased());
        
        let totalDeleted = 0;
        let totalTooOld = 0;
        let channelsScanned = 0;

        // Beri tahu user bahwa bot sedang mulai bekerja
        await interaction.editReply({ embeds: [redEmbed(`Memulai pemindaian hingga **${MAX_SCAN}** pesan per channel dari **${target.username}** di **${textChannels.size}** channel...\n\n*Proses ini mungkin memakan waktu beberapa detik hingga satu menit tergantung jumlah channel.*`, '🔄 Scanning Server...')] });

        // Mulai perulangan memindai setiap channel
        for (const [_, channel] of textChannels) {
            try {
                // Pastikan bot punya akses untuk melihat channel dan menghapus pesan di channel tersebut
                const botPerms = channel.permissionsFor(interaction.guild.members.me);
                if (!botPerms || !botPerms.has(PermissionFlagsBits.ViewChannel) || !botPerms.has(PermissionFlagsBits.ManageMessages)) {
                    continue; // Skip ke channel berikutnya jika tidak ada izin
                }
                
                // Kumpulkan pesan
                const msgs = await collectUserMessages(channel, target.id, MAX_SCAN);
                
                if (msgs.length > 0) {
                    const { deleted, tooOld } = await bulkDeleteMessages(channel, msgs);
                    totalDeleted += deleted;
                    totalTooOld += tooOld;
                }
                
                channelsScanned++;
            } catch (err) {
                // Abaikan error di satu channel agar proses di channel lain tetap berlanjut
                console.error(`Gagal memindai channel ${channel.name}:`, err.message);
            }
        }

        // Tampilkan hasil akhir
        let desc = `Berhasil memindai **${channelsScanned}** channel yang dapat diakses.\nMenghapus total **${totalDeleted}** pesan dari **${target.username}** di seluruh server.`;
        
        if (totalTooOld > 0) desc += `\n\n**${totalTooOld}** pesan dilewati karena usianya lebih dari 14 hari (Batas API Discord).`;
        if (totalDeleted === 0) desc = `Tidak ada pesan dari **${target.username}** yang ditemukan (dalam batas ${MAX_SCAN} pesan terakhir) di seluruh server.`;

        return interaction.editReply({ embeds: [redEmbed(desc, '✅ Messages Cleared (Server-Wide)')] });
    },
};


const deletemsgCmd = {
    data: new SlashCommandBuilder()
        .setName('deletemsg')
        .setDescription('Delete a set number of a user\'s recent messages in this channel')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addUserOption(o => o.setName('user').setDescription('The user whose messages will be deleted').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('How many messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageMessages))
            return interaction.editReply({ embeds: [redEmbed('I\'m missing the **Manage Messages** permission in this server.', 'Missing Permission')] });

        const target = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');
        const all = await collectUserMessages(interaction.channel, target.id, MAX_SCAN);
        const toDelete = all.slice(0, amount);

        if (toDelete.length === 0) return interaction.editReply({ embeds: [redEmbed(`No messages from **${target.username}** were found.`, 'Nothing to Delete')] });

        const { deleted, tooOld } = await bulkDeleteMessages(interaction.channel, toDelete);
        let desc = `Deleted **${deleted}** message(s) from **${target.username}**.`;
        if (tooOld > 0) desc += `\n\n**${tooOld}** message(s) were skipped because they are older than 14 days (Discord limit).`;

        return interaction.editReply({ embeds: [redEmbed(desc, 'Messages Deleted')] });
    },
};

const copypermCmd = {
    data: new SlashCommandBuilder()
        .setName('copyperm')
        .setDescription('Copy permissions from one channel to another (overwrites the target)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
        .addChannelOption(o => o.setName('source').setDescription('Channel to copy permissions FROM').setRequired(true))
        .addChannelOption(o => o.setName('target').setDescription('Channel to copy permissions TO (will be overwritten)').setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels))
            return interaction.editReply({ embeds: [redEmbed('I\'m missing the **Manage Channels** permission in this server.', 'Missing Permission')] });

        const source = interaction.options.getChannel('source');
        const target = interaction.options.getChannel('target');

        if (source.id === target.id) return interaction.editReply({ embeds: [redEmbed('The source and target channels must be different.', 'Invalid Selection')] });
        if (!source.permissionOverwrites || !target.permissionOverwrites) return interaction.editReply({ embeds: [redEmbed('One of the channels does not support permission overwrites.', 'Unsupported Channel')] });

        try {
            const overwrites = source.permissionOverwrites.cache.map(ow => ({
                id: ow.id, type: ow.type, allow: ow.allow.bitfield, deny: ow.deny.bitfield,
            }));
            await target.permissionOverwrites.set(overwrites);
            const embed = new EmbedBuilder().setColor(RED).setTitle('Permissions Copied')
                .setDescription(`Permissions from **${source.name}** were copied to **${target.name}**.`)
                .addFields(
                    { name: 'Source', value: `${source} (\`${source.id}\`)`, inline: false },
                    { name: 'Target', value: `${target} (\`${target.id}\`)`, inline: false },
                    { name: 'Overwrites Applied', value: `${overwrites.length}`, inline: true },
                ).setFooter({ text: `By ${interaction.user.tag}` }).setTimestamp();
            return interaction.editReply({ embeds: [embed] });
        } catch (err) {
            return interaction.editReply({ embeds: [redEmbed(err.message, 'Copy Failed')] });
        }
    },
};

const addresponderCmd = {
    data: new SlashCommandBuilder()
        .setName('addresponder')
        .setDescription('Tambah auto-responder (Khusus Admin/Mod)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption(o => o.setName('trigger').setDescription('Kata kunci pemicu (contoh: halo donatur)').setRequired(true))
        .addStringOption(o => o.setName('reply').setDescription('Balasan dari bot').setRequired(true))
        .addUserOption(o => o.setName('user').setDescription('Pilih donatur/user yang bisa men-trigger kata kunci ini').setRequired(true)),
    async execute(interaction) {
        const trigger = interaction.options.getString('trigger').toLowerCase().trim();
        const reply = interaction.options.getString('reply');
        const targetUser = interaction.options.getUser('user');

        responders.set(trigger, { reply: reply, ownerId: targetUser.id });
        saveResponders(responders);

        return interaction.reply({ embeds: [redEmbed(`Kata kunci **${trigger}** berhasil ditambahkan khusus untuk ${targetUser}.\n\n**Balasan:**\n${reply}`, 'Auto-Responder Ditambahkan')], ephemeral: true });
    }
};

const delresponderCmd = {
    data: new SlashCommandBuilder()
        .setName('delresponder')
        .setDescription('Hapus auto-responder (Khusus Admin/Mod)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption(o => o.setName('trigger').setDescription('Kata kunci yang mau dihapus').setRequired(true)),
    async execute(interaction) {
        const trigger = interaction.options.getString('trigger').toLowerCase().trim();

        if (!responders.has(trigger)) {
            return interaction.reply({ embeds: [redEmbed(`Kata kunci **${trigger}** tidak ditemukan di database.`, 'Tidak Ditemukan')], ephemeral: true });
        }

        responders.delete(trigger);
        saveResponders(responders);

        return interaction.reply({ embeds: [redEmbed(`Kata kunci **${trigger}** berhasil dihapus.`, 'Auto-Responder Dihapus')], ephemeral: true });
    }
};

const listresponderCmd = {
    data: new SlashCommandBuilder()
        .setName('listresponder')
        .setDescription('Lihat daftar semua auto-responder'),
    async execute(interaction) {
        if (responders.size === 0) {
            return interaction.reply({ embeds: [redEmbed('Belum ada auto-responder yang diatur.', 'Daftar Auto-Responder')], ephemeral: true });
        }

        let list = '';
        for (const [trigger, data] of responders) {
            const owner = data.ownerId ? `<@${data.ownerId}>` : 'Semua User';
            const reply = data.reply || data; 
            list += `• **Trigger:** \`${trigger}\`\n  **User:** ${owner}\n  **Reply:** ${reply}\n\n`;
        }

        return interaction.reply({ embeds: [redEmbed(list, 'Daftar Auto-Responder')], ephemeral: true });
    }
};

const commands = [helpCmd, banCmd, clearmsgCmd, deletemsgCmd, copypermCmd, setupRadarCmd, addresponderCmd, delresponderCmd, listresponderCmd];
const commandData = commands.map(c => c.data.toJSON());

async function registerToGuild(guild) {
    await guild.commands.set(commandData).catch(() => null);
}

client.once('ready', async () => {
    console.log(`✅ Bot online as ${client.user.tag}`);
    for (const [, guild] of client.guilds.cache) {
        await registerToGuild(guild);
    }
    client.user.setActivity('/help', { type: ActivityType.Listening });
});

client.on('guildCreate', registerToGuild);

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (!interaction.inGuild()) return;

    const hasWhitelist = WHITELIST_ROLES.some(roleId => interaction.member.roles.cache.has(roleId));
    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);

    if (!hasWhitelist && !isAdmin) {
        return interaction.reply({ 
            content: '⛔ Akses ditolak. Anda tidak memiliki role whitelist untuk menggunakan perintah ini.', 
            ephemeral: true 
        });
    }

    const cmd = commands.find(c => c.data.name === interaction.commandName);
    if (!cmd) return;

    try {
        await cmd.execute(interaction);
    } catch (err) {
        const content = `An error occurred: ${err.message}`;
        if (interaction.deferred || interaction.replied) {
            interaction.editReply({ content }).catch(() => null);
        } else {
            interaction.reply({ content, ephemeral: true }).catch(() => null);
        }
    }
});

client.on('messageCreate', async (message) => {
    try {
        if (message.author.bot || !message.inGuild()) return;

        // Command "gosmed" — balas info sosial media Gokaizen (semua member bisa pakai)
        if (message.content.trim().toLowerCase() === 'gosmed') {
            await message.reply({
                content: GOSMED_REPLY,
                allowedMentions: { repliedUser: false }
            }).catch(() => null);
            return;
        }

        // Auto-Responder Logic
        if (!message.content.startsWith('.')) {
            const msgContent = message.content.trim().toLowerCase();
            if (responders.has(msgContent)) {
                const data = responders.get(msgContent);
                
                const isOwner = data.ownerId ? (message.author.id === data.ownerId) : true;
                const replyContent = data.reply || data;

                if (isOwner) {
                    // --- BALASAN TEKS BIASA ---
                    await message.reply({ 
                        content: replyContent, 
                        allowedMentions: { repliedUser: false } 
                    }).catch(() => null);
                }
            }
        }
        
        

        // Warp Logic
        if (message.content.startsWith('.')) {
            const args = message.content.slice(1).trim().split(/ +/);
            const command = args.shift()?.toLowerCase();

            if (command === 'warp') {
                const hasPermission = WHITELIST_ROLES.some(roleId => message.member.roles.cache.has(roleId));
                if (!hasPermission) return;

                const userVC = message.member.voice.channel;

                if (!userVC) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('❌ Harus di Voice Channel').setDescription('Kamu harus berada di voice channel untuk menggunakan `.warp`.')] });
                }

                if (!args[0]) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('Yellow')
                                .setTitle('📌 Cara Penggunaan')
                                .setDescription('Gunakan mention, ID, atau `random`.')
                                .addFields({
                                    name: 'Contoh',
                                    value: '`.warp @user`\n`.warp 123456789012345678`\n`.warp random`'
                                })
                        ]
                    });
                }

                let target;

                if (args[0].toLowerCase() === 'random') {
                    const voiceMembers = message.guild.members.cache.filter(member =>
                        member.voice.channel &&
                        !member.user.bot &&
                        member.id !== message.member.id
                    );

                    if (!voiceMembers.size) {
                        return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('❌ Tidak Ada User').setDescription('Tidak ada member valid di voice channel.')] });
                    }
                    target = voiceMembers.random();
                } else {
                    if (message.mentions.members.size > 0) {
                        target = message.mentions.members.first();
                    } else {
                        const userId = args[0].replace(/\D/g, '');
                        if (!userId) return;
                        target = await message.guild.members.fetch(userId).catch(() => null);
                    }
                }

                if (!target) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('❌ User Tidak Ditemukan')] });
                }

                if (target.user.bot) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('❌ Tidak Bisa Warp Bot').setDescription('Bot tidak bisa dijadikan target warp.')] });
                }

                if (!target.voice.channel) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('❌ Gagal Warp').setDescription(`${target.user.tag} tidak berada di voice channel.`)] });
                }

                const targetVC = target.voice.channel;

                if (targetVC.id === userVC.id) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Yellow').setTitle('⚠️ Sudah Satu VC').setDescription(`Kamu sudah berada di voice yang sama dengan ${target.user.tag}.`)] });
                }

                const everyoneOverwrite = targetVC.permissionOverwrites.cache.get(message.guild.id);
                if (everyoneOverwrite && everyoneOverwrite.deny.has(PermissionsBitField.Flags.Connect)) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('🔒 Voice Channel Dikunci').setDescription('Voice channel target sedang di-lock.')] });
                }

                const userLimit = targetVC.userLimit;
                if (userLimit > 0 && targetVC.members.size >= userLimit) {
                    return message.reply({ embeds: [new EmbedBuilder().setColor('Red').setTitle('🚫 Voice Channel Penuh').setDescription(`Voice channel target penuh (${targetVC.members.size}/${userLimit}).`)] });
                }

                let warpSuccess = true;
                try {
                    await message.member.voice.setChannel(targetVC);
                } catch (err) {
                    warpSuccess = false;
                }

                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(warpSuccess ? 'Green' : 'Red')
                            .setTitle(warpSuccess ? '🌀 Warp Berhasil' : '❌ Warp Gagal')
                            .setDescription(warpSuccess ? `Berhasil dipindahkan ke VC ${target}.` : `Gagal dipindahkan ke VC ${target}.`)
                            .addFields(
                                { name: '🎧 Voice Channel', value: `${targetVC.name}`, inline: true },
                                { name: '👥 Jumlah User', value: `${targetVC.members.size} orang`, inline: true }
                            )
                            .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
                            .setTimestamp()
                    ]
                });
            }
        }

        // Radar Anti-Scam Logic
        const imageAttachments = message.attachments.filter((att) =>
            (att.contentType && att.contentType.startsWith('image/')) ||
            /\.(png|jpe?g|gif|webp)$/i.test(att.name ?? '')
        );

        if (imageAttachments.size >= IMAGE_THRESHOLD) {
            const radarChannelId = radarChannels.get(message.guild.id);
            if (!radarChannelId) return;

            const radarChannel = message.guild.channels.cache.get(radarChannelId)
                ?? await message.guild.channels.fetch(radarChannelId).catch(() => null);
            if (!radarChannel || !radarChannel.isTextBased()) return;

            const radarEmbed = new EmbedBuilder()
                .setTitle('RADAR GOKAIZEN: INDIKASI SCAM')
                .setColor(RED)
                .setDescription(`Terdeteksi pola serangan akun hacked (mengirim ${imageAttachments.size} gambar sekaligus). Segera lakukan pengecekan manual.`)
                .addFields(
                    { name: 'User', value: `${message.author} (${message.author.id})`, inline: true },
                    { name: 'Lokasi', value: `${message.channel}`, inline: true },
                    { name: 'Link Pesan', value: `[Klik di sini untuk melihat pesan](${message.url})`, inline: false }
                )
                .setFooter({ text: '\u200b', iconURL: client.user.displayAvatarURL() })
                .setTimestamp();

            const mentionContent = ALERT_ROLES.map((id) => `<@&${id}>`).join(' ');

            await radarChannel.send({
                content: mentionContent,
                embeds: [radarEmbed],
                allowedMentions: { roles: ALERT_ROLES }
            }).catch(() => null);
        }
    } catch (err) {}
});

process.on('unhandledRejection', () => {});
process.on('uncaughtException', () => {});

client.login(TOKEN);
